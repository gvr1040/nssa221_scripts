"""
Gray Reyes - NSSA Script02
collets system info and prints it out
"""
import os
import subprocess
import platform
import datetime
import re


def run_cmd(args):
	try:
		result = subprocess.run(args, capture_output=True, text=True,check=False)
		return result.stdout.strip()
	
	except Exception:
		return ""

def get_hostname():
	return platform.node()

def get_domain():
	domain = run_cmd(["hostname", "-d"])
	if domain == "":
		parts = get_hostname().split(".")
		if len(parts) > 1:
			domain = ".".join(parts[1:])
		else:
			domain = "N/A"
	return domain

def get_ip_address():
	ip_info = run_cmd(["ip", "addr","show"])
	match = re.search(r"default via (\d+\.\d+\.\d+\.\d+)", route_info)
	return match.group(1) if match else "N/A"


def get_gateway():
	route_info = run_cmd(["ip", "route"])
	match = re.search(r"default via (\d+\.\d+\.\d+\.\d+)", route_info)
	return match.group(1) if match else "N/A"

def get_netmask():
	ip_info = run_cmd(["ip", "-o", "-f","inet", "addr", "show"])
	match = re.search(r"inet (\d+\.\d+\.\d+\.\d+/(\d+)", ip_info)
	if match:
		prefix = int(match.group(1))
		mask = (0xffffffff >>(32 - prefix)) << (32 - prefix)
		return ".".join(str((mask>> i) & 0xff) for i in [24,16,8,0])
	return "N/A"

def get_dns():
	resolv = run_cmd(["cat", "/etc/resolv.conf"])
	dns = re.findall(r"nameserver (\d+\.\d+\.\d+\.\d+)", resolv)
	if len(dns) >= 2:
		return dns[0], dns[1]
	elif len(dns)==1:
		return dns [0], "N/A"
	else:
		return "N/A", "N/A"

def get_os():
	name = platform.system()
	version = platform.version()
	distro = ""
	try:
		with open ("/etc/os-release") as f:
			for line in f:
				if line.startswith("NAME"):
					distro = line.strip().split("=")[1].strip('"')
	except:
		distro = name 
	kernel = platform.release()
	return name, distro, version, kernel 

def get_storage():
	df = run_cmd(["df", "-h", "/"])
	lines = df.splitlines()
	if len(lines) >=2:
		parts = lines[1].split()
		return parts[1],parts[2],parts[3]
	return "N/A","N/A","N/A"


def get_cpu():	
	cpu_text = run_cmd(["lscpu"])
	model = re.search (r"Model name:\s+(.*)", cpu_text)
	sockets = re.search(r"Socjet\(s\):\s+(\d+)", cpu_text)
	cores = re.search (r"Core\(s\) per socket:\s+(\d+)", cpu_text)
	return (
		model.group(1) if model else "N/A",
		sockets.group(1) if sockets else "N/A",
		cores.group(1) if cores else "N/A"
	)
def get_ram():
	free_out = run_cmd(["free", "-h"])
	lines = free_out.splitlines()
	for line in lines:
		if line.startswith("Mem:"):
			parts = line.split()
			total = parts[1]
			available = parts[6]
			return total,available
	return "N/A", "N/A"



def report():
	now = datetime.datetime.now()
	date_str = now.strftime("%B %d,%Y")
	hostname = get_hostname()
	domain = get_domain()
	ip = get_ip_address()
	gateway = get_gateway()
	netmask = get_netmask()
	dns1, dns2 = get_dns()
	os_name,os_distro, os_version, kernel = get_os()
	total_disk, used_disk, free_disk = get_storage()
	cpu_model, num_processorts,num_cores = get_cpu()
	total_ram,avail_ram=get_ram()

	report = []
	report.append("System Report - " + date_str)
	report.append("\nDevice Information")
	report.aooend("Host Name: "+ hostname)
	report.append("Domain: " +domain)
	report.append("\nNetwork Information")
	report.append("IP Address: " +ip)
	report.append("Gateway: " + gateway)
	report.append("Network Mask: ")
	report.append("DNS1: " + dns1)
	report.append("DNS2: " + dns2)
	report.append("\nOperation System Information ")
	report.append("Operating System : " +os_distro )
	report.append("OS Version: " +os_version)
	report.append("Kernel Version:" + kernel)
	report.append("\nStorage Information")
	report.append("System Drive Total : " + total_disk)
	report.append("System Drive Used:" + used_disk)
	report.append("\nProcessor Information")
	report.append("CPU model: "+ cpu_model)
	report.append("Number of Processors: " + num_processors)
	report.append("Number of cores: " + num_cores)
	report.append("\n Memory Information")
	report.append("Total RAM: " +total_ram)
	report.append("Available RAM: " + avail_ram)

	return "\n".join(report)


def main():
	print_report = report()
	print(print_report)
	filename = platform.node() + "_system_report.log"
	home = os.path.expanduser("~")
	path = os.path.join(home,filename)
	try:
		with open(path, "w") as f:
			f.write(report)
		print("\nReport Saved to: "+path)
	except Exception as e:
		print("Failed to save report:" , e)

if __name__ == "__main__":
	main()












				








	





















